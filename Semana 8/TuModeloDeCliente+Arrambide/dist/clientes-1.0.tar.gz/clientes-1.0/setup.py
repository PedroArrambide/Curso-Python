from setuptools import setup

setup(
    name = "clientes",
    version = "1.0",
    packages=["clientes"],
)